print "Content-Type: text/plain"
print ""
print "Congratulations, it's a web app!"